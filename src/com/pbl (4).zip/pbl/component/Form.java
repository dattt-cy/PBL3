package com.pbl.component;

import java.awt.Color;
import javax.swing.JPanel;

public class Form extends JPanel {

    public Form() {
        setOpaque(false);
    }

    public void changeColor(Color color) {

    }
}
