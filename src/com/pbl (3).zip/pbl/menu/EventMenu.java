package com.pbl.menu;

public interface EventMenu {

    public void selectedMenu(int index);
}
