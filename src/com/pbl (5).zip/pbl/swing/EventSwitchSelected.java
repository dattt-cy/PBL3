package com.pbl.swing;

public interface EventSwitchSelected {

    public void onSelected(boolean selected);
}
