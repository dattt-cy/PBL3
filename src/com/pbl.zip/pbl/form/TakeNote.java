
package com.pbl.form;
import com.pbl.model.Takenote;
import com.pbl.service.TakeNoteService;

import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class TakeNote extends JFrame {
    private final TakeNoteService takeNoteService = new TakeNoteService();
    private final DefaultListModel<Takenote> listModel = new DefaultListModel<>();
    private final JList<Takenote> listNotes = new JList<>(listModel);
    private final JTextField txtTitle   = new JTextField();
    private final JTextArea  txtContent = new JTextArea();
    private final JLabel     lblDate    = new JLabel();
    private final JButton    btnAdd     = new JButton("+ Add");
    private final JButton    btnSave    = new JButton("Save");
    private final JButton    btnDelete  = new JButton("Delete");

    private Takenote currentNote;
    private final int currentUserId; // TODO: Thay bằng ID user hiện hành

    public TakeNote(int userID) {
        currentUserId = userID;
        super("Take Note");
        initUI();
        loadNotes();
        initEvents();
    }

    private void initUI() {
        setSize(800, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
        splitPane.setDividerLocation(250);
        add(splitPane);

        // Panel trái: danh sách ghi chú
        listNotes.setCellRenderer(new TakenoteCellRenderer());
        splitPane.setLeftComponent(new JScrollPane(listNotes));

        // Panel phải: form chi tiết
        JPanel detailPanel = new JPanel(new BorderLayout(10, 10));
        detailPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Tiêu đề
        txtTitle.setFont(txtTitle.getFont().deriveFont(16f));
        detailPanel.add(txtTitle, BorderLayout.NORTH);

        // Nội dung
        txtContent.setLineWrap(true);
        txtContent.setWrapStyleWord(true);
        detailPanel.add(new JScrollPane(txtContent), BorderLayout.CENTER);

        // Panel dưới: ngày tạo + nút hành động
        JPanel bottomPanel = new JPanel(new BorderLayout(10, 0));
        bottomPanel.add(lblDate, BorderLayout.WEST);

        JPanel btnPanel = new JPanel();
        btnAdd.setBorder(new RoundedBorder(12));
        btnSave.setBorder(new RoundedBorder(12));
        btnDelete.setBorder(new RoundedBorder(12));
        btnPanel.add(btnAdd);
        btnPanel.add(btnSave);
        btnPanel.add(btnDelete);

        bottomPanel.add(btnPanel, BorderLayout.EAST);
        detailPanel.add(bottomPanel, BorderLayout.SOUTH);
        splitPane.setRightComponent(detailPanel);
    }

    private void loadNotes() {
        listModel.clear();
        List<Takenote> notes = takeNoteService.loadAll(currentUserId);
        for (Takenote note : notes) {
            listModel.addElement(note);
        }
    }

    private void initEvents() {
        // Chọn ghi chú từ danh sách
        listNotes.addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                currentNote = listNotes.getSelectedValue();
                if (currentNote != null) {
                    txtTitle.setText(currentNote.getTitle());
                    txtContent.setText(currentNote.getContent());
                    lblDate.setText(
                        currentNote.getCreatedAt()
                                   .format(DateTimeFormatter.ofPattern("MMM d, yyyy"))
                    );
                }
            }
        });

        // Thêm mới
        btnAdd.addActionListener(e -> {
            currentNote = null;
            txtTitle.setText("");
            txtContent.setText("");
            lblDate.setText("");
            listNotes.clearSelection();
        });

        // Lưu (insert hoặc update)
        btnSave.addActionListener(e -> {
            if (currentNote == null) {
                Takenote newNote = new Takenote(0, currentUserId,
                    txtTitle.getText(), txtContent.getText(), null);
                takeNoteService.add(newNote);
            } else {
                currentNote.setTitle(txtTitle.getText());
                currentNote.setContent(txtContent.getText());
                takeNoteService.update(currentNote);
            }
            loadNotes();
        });

        // Xóa
        btnDelete.addActionListener(e -> {
            if (currentNote != null) {
                takeNoteService.delete(currentNote.getId());
                loadNotes();
                btnAdd.doClick();
            }
        });
    }

//    public static void main(String[] args) {
//        SwingUtilities.invokeLater(() -> {
//            new TakeNote(currentUserId).setVisible(true);
//        });
//    }

    // ===== Inner class: bo góc nút =====
    private static class RoundedBorder implements Border {
        private final int radius;
        public RoundedBorder(int radius) { this.radius = radius; }
        @Override public Insets getBorderInsets(Component c) {
            return new Insets(radius+1, radius+1, radius+2, radius);
        }
        @Override public boolean isBorderOpaque() { return false; }
        @Override public void paintBorder(Component c, Graphics g,
                                         int x, int y, int w, int h) {
            g.drawRoundRect(x, y, w-1, h-1, radius, radius);
        }
    }

    // ===== Inner class: renderer cho Takenote =====
    private static class TakenoteCellRenderer implements ListCellRenderer<Takenote> {
        private static final DateTimeFormatter FMT =
            DateTimeFormatter.ofPattern("MMM d, yyyy");

        @Override
        public Component getListCellRendererComponent(
                JList<? extends Takenote> list,
                Takenote note,
                int index,
                boolean isSelected,
                boolean cellHasFocus) {

            JPanel panel = new JPanel(new BorderLayout());
            panel.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
            panel.setOpaque(true);

            JLabel lblTitle = new JLabel(note.getTitle());
            JLabel lblCreated = new JLabel(note.getCreatedAt().format(FMT));
            lblCreated.setFont(lblCreated.getFont().deriveFont(12f));

            panel.add(lblTitle, BorderLayout.NORTH);
            panel.add(lblCreated, BorderLayout.SOUTH);

            panel.setBackground(isSelected ? new Color(255, 250, 205) : Color.WHITE);
            panel.setBorder(BorderFactory.createLineBorder(new Color(220, 220, 220)));
            return panel;
        }
    }
}
