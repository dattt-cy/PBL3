package com.pbl.event;

import java.awt.Component;

public interface EventShowPopupMenu {

    public void showPopup(Component com);
}
