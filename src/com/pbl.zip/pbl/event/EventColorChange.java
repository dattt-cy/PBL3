package com.pbl.event;

import java.awt.Color;

public interface EventColorChange {

    public void colorChange(Color color);
}
