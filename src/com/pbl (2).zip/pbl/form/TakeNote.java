
package com.pbl.form;
import com.pbl.model.Takenote;
import com.pbl.service.TakeNoteService;

import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class TakeNote extends JPanel {
    private final TakeNoteService takeNoteService = new TakeNoteService();
    private final DefaultListModel<Takenote> listModel = new DefaultListModel<>();
    private final JList<Takenote> listNotes = new JList<>(listModel);
    private final JTextField txtTitle   = new JTextField();
    private final JTextArea  txtContent = new JTextArea();
    private final JLabel     lblDate    = new JLabel();
    private final JButton    btnAdd     = new JButton("+ Add");
    private final JButton    btnSave    = new JButton("Save");
    private final JButton    btnDelete  = new JButton("Delete");

    private Takenote currentNote;
    private final int currentUserId;

    public TakeNote(int userId) {
        this.currentUserId = userId;
        initUI();
        loadNotes();
        initEvents();
    }

    private void initUI() {
        setLayout(new BorderLayout());
        setBackground(new Color(245, 245, 250));    // pastel nền
        setOpaque(true);

        // Wrapper với bo góc và nền pastel tím
        JPanel wrapper = new JPanel(new BorderLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                                    RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(new Color(193, 202, 255));    // pastel purple
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 30, 30);
                super.paintComponent(g);
                g2.dispose();
            }
        };
        wrapper.setOpaque(false);
        wrapper.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        add(wrapper, BorderLayout.CENTER);

        // Panel chính trắng bên trong
        JPanel main = new JPanel(new BorderLayout());
        main.setBackground(Color.WHITE);
        main.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        wrapper.add(main, BorderLayout.CENTER);

        // SplitPane chia danh sách và detail
        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
        splitPane.setDividerLocation(250);
        splitPane.setBorder(null);
        main.add(splitPane, BorderLayout.CENTER);

        // ===== LEFT: danh sách note =====
        listNotes.setCellRenderer(new TakenoteCellRenderer());
        listNotes.setBackground(new Color(230, 230, 255));
        listNotes.setSelectionBackground(new Color(255, 250, 205));
        listNotes.setOpaque(true);
        JScrollPane scrollList = new JScrollPane(listNotes);
        scrollList.setBorder(null);
        splitPane.setLeftComponent(scrollList);

        // ===== RIGHT: detail =====
        JPanel detailPanel = new JPanel(new BorderLayout(10, 10));
        detailPanel.setBackground(Color.WHITE);
        detailPanel.setBorder(BorderFactory.createEmptyBorder(0, 20, 0, 20));
        splitPane.setRightComponent(detailPanel);

        // Tiêu đề note
        txtTitle.setFont(txtTitle.getFont().deriveFont(16f));
        txtTitle.setBackground(Color.WHITE);
        txtTitle.setBorder(BorderFactory.createLineBorder(new Color(200, 200, 255), 2, true));
        detailPanel.add(txtTitle, BorderLayout.NORTH);

        // Nội dung note
        txtContent.setLineWrap(true);
        txtContent.setWrapStyleWord(true);
        txtContent.setBackground(Color.WHITE);
        txtContent.setBorder(BorderFactory.createLineBorder(new Color(200, 200, 255), 2, true));
        detailPanel.add(new JScrollPane(txtContent), BorderLayout.CENTER);

        // === Bottom: ngày + nút ===
        JPanel bottom = new JPanel(new BorderLayout(10, 0));
        bottom.setBackground(Color.WHITE);
        lblDate.setFont(lblDate.getFont().deriveFont(14f));
        bottom.add(lblDate, BorderLayout.WEST);

        JPanel btnPanel = new JPanel();
        btnPanel.setBackground(Color.WHITE);
        styleButton(btnAdd,    new Color( 66,150,242));  // xanh
        styleButton(btnSave,   new Color(123,139,245));  // tím nhạt
        styleButton(btnDelete, new Color(240, 95, 87));  // đỏ
        btnPanel.add(btnAdd);
        btnPanel.add(btnSave);
        btnPanel.add(btnDelete);
        
        splitPane.setEnabled(false);
        splitPane.setDividerSize(0);
        splitPane.setDividerLocation(250);

        bottom.add(btnPanel, BorderLayout.EAST);

        detailPanel.add(bottom, BorderLayout.SOUTH);
    }

    // Style cho nút: bo góc, màu nền, chữ trắng
    private void styleButton(JButton btn, Color bg) {
        btn.setBackground(bg);
        btn.setForeground(Color.WHITE);
        btn.setOpaque(true);
        btn.setContentAreaFilled(true);
        btn.setBorder(new RoundedBorder(12));
        btn.setFocusPainted(false);
    }

    // Load dữ liệu
    private void loadNotes() {
        listModel.clear();
        List<Takenote> notes = takeNoteService.loadAll(currentUserId);
        notes.forEach(listModel::addElement);
    }

    // Event handler
    private void initEvents() {
        listNotes.addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                currentNote = listNotes.getSelectedValue();
                if (currentNote != null) {
                    txtTitle.setText(currentNote.getTitle());
                    txtContent.setText(currentNote.getContent());
                    lblDate.setText(
                        currentNote.getCreatedAt()
                                   .format(DateTimeFormatter.ofPattern("MMM d, yyyy"))
                    );
                }
            }
        });
        btnAdd.addActionListener(e -> {
            currentNote = null;
            txtTitle.setText(""); txtContent.setText(""); lblDate.setText("");
            listNotes.clearSelection();
        });
        btnSave.addActionListener(e -> {
            if (currentNote == null) {
                Takenote n = new Takenote(0, currentUserId,
                    txtTitle.getText(), txtContent.getText(), null);
                takeNoteService.add(n);
            } else {
                currentNote.setTitle(txtTitle.getText());
                currentNote.setContent(txtContent.getText());
                takeNoteService.update(currentNote);
            }
            loadNotes();
        });
        btnDelete.addActionListener(e -> {
            if (currentNote != null) {
                takeNoteService.delete(currentNote.getId());
                loadNotes();
                btnAdd.doClick();
            }
        });
    }

    // Inner class: bo góc
    private static class RoundedBorder implements Border {
        private final int radius;
        public RoundedBorder(int radius) { this.radius = radius; }
        @Override public Insets getBorderInsets(Component c) {
            return new Insets(radius+1, radius+1, radius+2, radius);
        }
        @Override public boolean isBorderOpaque() { return false; }
        @Override public void paintBorder(Component c, Graphics g,
                                         int x, int y, int width, int height) {
            g.drawRoundRect(x, y, width-1, height-1, radius, radius);
        }
    }

    // Inner class: renderer list
    private static class TakenoteCellRenderer implements ListCellRenderer<Takenote> {
        private static final DateTimeFormatter FMT =
            DateTimeFormatter.ofPattern("MMM d, yyyy");
        @Override
        public Component getListCellRendererComponent(
                JList<? extends Takenote> list,
                Takenote note,
                int index,
                boolean isSelected,
                boolean cellHasFocus) {
            JPanel panel = new JPanel(new BorderLayout());
            panel.setBorder(BorderFactory.createEmptyBorder(8,8,8,8));
            panel.setOpaque(true);
            JLabel t = new JLabel(note.getTitle());
            JLabel d = new JLabel(note.getCreatedAt().format(FMT));
            d.setFont(d.getFont().deriveFont(12f));
            panel.add(t, BorderLayout.NORTH);
            panel.add(d, BorderLayout.SOUTH);
            panel.setBackground(isSelected
                ? new Color(255,250,205)
                : Color.WHITE);
            panel.setBorder(BorderFactory.createLineBorder(new Color(220,220,220)));
            return panel;
        }
    }
}
