package com.pbl.model;

public enum StatusType {
    DONE, NODONE
}
